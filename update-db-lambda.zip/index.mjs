import { DynamoDBClient, PutItemCommand, QueryCommand, DeleteItemCommand } from '@aws-sdk/client-dynamodb';
import https from 'https';
import { URL } from 'url';

// Initialize DynamoDB Client
const dynamoDBClient = new DynamoDBClient({ region: 'us-east-1' });

// List of tickers to monitor
const tickers = [
    "AAPL", "MSFT", "NVDA", "GOOG", "AMZN", "META", "BRKB", "LLY", "AVGO", "TSLA"
];

export const handler = async (event) => {
    try {
        const apiUrl = 'https://ftl.fasttrack.net/v1/data/xmulti/range';
        const headers = {
            'Appid': '82435e40-9113-4d34-a98c-2ad48019b4f1',
            'Token': 'A74E750B-B100-4775-B0A1-6AB529C2E68F',
            'Content-Type': 'application/json'
        };

        const currentDate = new Date();
        const year = currentDate.getFullYear();
        const month = String(currentDate.getMonth() + 1).padStart(2, '0'); // Months are zero-based, so add 1
        const day = String(currentDate.getDate()).padStart(2, '0');
        const formattedDate = `${year}-${month}-${day}`;
        const params = new URLSearchParams({ start: formattedDate }).toString();
        const body = JSON.stringify(tickers);

        const options = {
            method: 'POST',
            headers: headers,
            path: `${apiUrl}?${params}`,
            hostname: new URL(apiUrl).hostname
        };

        const response = await new Promise((resolve, reject) => {
            const req = https.request(options, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => resolve(JSON.parse(data)));
            });

            req.on('error', (error) => reject(error));
            req.write(body);
            req.end();
        });

        const data = response.datalist;

        // Insert the latest price for each ticker
        for (const stockData of data) {
            const ticker = stockData.ticker;

            for (const entry of stockData.datarange) {
                const formattedDate = convertToISODate(entry.date.strdate);

                const item = {
                    TableName: 'MarketDB',
                    Item: {
                        date: { S: formattedDate }, // Use the formatted date as partition key
                        ticker: { S: ticker },      // Use ticker as sort key
                        price: { N: entry.price.toString() }
                    }
                };

                // Log the item structure to help debug
                console.log('Item to be inserted:', item);

                // Create the PutItem command
                const putItemCommand = new PutItemCommand(item);
                await dynamoDBClient.send(putItemCommand);
            }

            // Delete the oldest date for the ticker
            await deleteOldestDate(ticker);
        }

        return {
            statusCode: 200,
            body: JSON.stringify('Prices updated today.')
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify('Failed to update prices today.')
        };
    }
};

// Function to convert date string to ISO format
const convertToISODate = (dateStr) => {
    const [month, day, year] = dateStr.split('/').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.toISOString();
};

// Function to delete the oldest date for a ticker
const deleteOldestDate = async (ticker) => {
    // Query the database to get all records for the ticker
    const queryCommand = new QueryCommand({
        TableName: 'MarketDB',
        KeyConditionExpression: 'ticker = :ticker',
        ExpressionAttributeValues: {
            ':ticker': { S: ticker }
        },
        ScanIndexForward: true,
        Limit: 1 
    });

    const result = await dynamoDBClient.send(queryCommand);
    
    // Delete oldest entry for each ticker
    if (result.Items.length > 0) {
        const oldestItem = result.Items[0];
        const deleteCommand = new DeleteItemCommand({
            TableName: 'MarketDB',
            Key: {
                date: { S: oldestItem.date.S }, 
                ticker: { S: ticker }
            }
        });
        await dynamoDBClient.send(deleteCommand);
        console.log(`Deleted oldest entry for ticker ${ticker}:`, oldestItem);
    } else {
        console.log(`No entries found for ticker ${ticker}`);
    }
};
